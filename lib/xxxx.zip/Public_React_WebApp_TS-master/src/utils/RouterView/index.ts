/*
 * @LastEditors: Mark
 * @Description: none
 * @Author: Mark
 * @Date: 2019-07-02 17:46:52
 * @LastEditTime: 2019-07-03 03:08:01
 */
import RenderView from './RenderView';
export const RouterView = RenderView;
export * from './inspectRouter';

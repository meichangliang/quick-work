/*
 * @LastEditors: Mark
 * @Description: none
 * @Author: Mark
 * @Date: 2019-06-17 23:30:28
 * @LastEditTime: 2019-06-18 21:50:30
 */

export const PROJECT_DETAIL = { name: process.env.REACT_APP_PROJECT_NAME };
export const HTML_FONTSIZE = process.env.REACT_APP_HTML_FONTSIZE;

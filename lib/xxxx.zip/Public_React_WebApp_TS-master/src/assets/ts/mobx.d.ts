/*
 * @LastEditors: Mark
 * @Description: none
 * @Author: Mark
 * @Date: 2019-06-17 23:26:55
 * @LastEditTime: 2019-07-03 02:21:05
 */

declare module 'mobx' {
  const { observable, action, computed };
}

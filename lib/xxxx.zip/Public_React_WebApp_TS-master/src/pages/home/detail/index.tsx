/*
* @LastEditors: Mark
 * @Description: none
 * @Author: Mark
 * @Date: 2019-07-03 02:20:03
* @LastEditTime: 2019-07-29 14:40:38
 */
import React from 'react';

export default class extends React.Component {
  render() {
    return (
      <div>
        <h2>这里是详情页面</h2>
      </div>
    );
  }
}

import React, { Component } from 'react';
class NotFound extends Component {
  render() {
    return (
      <div>
        <h1> 404 NotFound , 你访问的页面不存在 </h1>
      </div>
    );
  }
}

export default NotFound;

/*
 * @LastEditors: Mark
 * @Description: none
 * @Author: Mark
 * @Date: 2019-07-03 02:20:03
 * @LastEditTime: 2019-07-03 02:43:59
 */
import React from 'react';

export default class extends React.Component {
  render() {
    return (
      <div>
        <h2>这里是 TypeScript 演示 , 二级路由</h2>
      </div>
    );
  }
}

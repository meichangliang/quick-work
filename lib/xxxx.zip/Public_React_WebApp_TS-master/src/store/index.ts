import homeStore from './home_store';
import otherStore from './others';
export { homeStore, otherStore };
